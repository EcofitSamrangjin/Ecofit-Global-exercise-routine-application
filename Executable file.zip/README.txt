**** If you want to use the file as is, compress it and use it as is. ****

This program is open source, so you can freely modify and distribute it.
You can add to it and fix any issues!
Translation is also free.
We welcome your free translation efforts.

The goal of this program is to provide a workout routine app in languages ​​from around the world.
We hope that talented individuals from around the world will help improve the shortcomings of our programs.
That's our intention!

Our program will be very amateurish.
So, please complete it! Give people around the world a chance!